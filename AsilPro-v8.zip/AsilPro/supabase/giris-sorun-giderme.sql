-- AsilPro: "Kullanıcı adı veya şifre hatalı" sorununu giderme
-- Supabase > SQL Editor'de, bölüm bölüm çalıştırın. Önce yalnızca 1) ve 2) sorgularını çalıştırın.
-- A) ve B) satırları "--" ile kapalıdır; kullanmak için o satırların başındaki "-- " işaretini silin.

-- 1) Hesaplar: uygulamanın denediği adres ile buradaki adres AYNI olmalı.
--    Kullanıcı adı "Koray" -> koray@asilpro.invalid
--    email_confirmed_at boş olmamalı. banned_until boş olmalı.
select id, email, email_confirmed_at, banned_until, last_sign_in_at
from auth.users order by created_at;

-- 2) Merkez profili var mı? (rol = merkez, ad = Koray)
select p.rol, p.ad, u.email
from public.profiller p join auth.users u on u.id = p.id;

-- A) Hesap onaylı değilse (email_confirmed_at boşsa):
-- update auth.users set email_confirmed_at = now()
-- where email = 'koray@asilpro.invalid' and email_confirmed_at is null;

-- B) Şifreyi yeniden belirlemek için (YENI_SIFRE yerine kendi şifrenizi yazın; bu dosyayı kaydetmeyin):
-- update auth.users
-- set encrypted_password = extensions.crypt('YENI_SIFRE', extensions.gen_salt('bf'))
-- where email = 'koray@asilpro.invalid';

-- C) Hesabı farklı bir e-postayla açtıysanız (1. sorguda görünen adres koray@asilpro.invalid değilse):
--    uygulamada "Kullanıcı adı" kutusuna o e-posta adresinin TAMAMINI yazarak da giriş yapabilirsiniz.
