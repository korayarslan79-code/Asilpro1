-- AsilPro: MERKEZ (yönetici) hesabı
-- Kullanıcı adı: Koray  ->  giriş adı  koray@asilpro.invalid  olarak tutulur.
-- Şifre bu dosyada YAZMAZ; şifreyi yalnızca Supabase panelinde siz yazarsınız.
--
-- 1) Supabase > Authentication > Users > Add user > Create new user
--      Email    : koray@asilpro.invalid
--      Password : (kendi belirlediğiniz şifre)
--      "Auto Confirm User" işaretli olsun.
-- 2) Sonra bu dosyayı SQL Editor'de çalıştırın (schema.sql'den SONRA):

insert into public.profiller (id, rol, ad)
select id, 'merkez', 'Koray'
from auth.users
where email = 'koray@asilpro.invalid'
on conflict (id) do nothing;

-- Kontrol: aşağıdaki sorgu 1 satır döndürmeli (rol = merkez)
select p.rol, p.ad, u.email from public.profiller p join auth.users u on u.id = p.id;
