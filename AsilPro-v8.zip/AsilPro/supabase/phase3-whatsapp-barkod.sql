-- AsilPro v8 (sade) - WhatsApp otomatik + barkod
-- Stok / KDV / çoklu dil YOK.
-- Mevcut proje: yedek al, SQL Editor'de çalıştır.

-- 1) Barkod (opsiyonel)
alter table public.fiyatlar add column if not exists barkod text;
create unique index if not exists fiyatlar_barkod_uidx on public.fiyatlar (barkod) where barkod is not null and barkod <> '';

-- 2) WhatsApp ayar anahtarı (token istemciye gitmemeli; Edge Function okur)
insert into public.ayarlar (anahtar, deger)
values (
  'whatsapp',
  jsonb_build_object(
    'auto', false,
    'phone_id', '',
    'token', '',
    'enabled', false
  )
)
on conflict (anahtar) do nothing;
