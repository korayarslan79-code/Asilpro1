-- AsilPro v7 - İade, ödeme silme, kasa indeksleri
-- Mevcut projede: önce yedek alın, sonra SQL Editor'de çalıştırın.
-- Yeni kurulumda schema.sql'den SONRA çalıştırın (veya schema güncellenmişse gerekmez).

-- 1) Ödemelerde negatif tutar (iade) serbest
alter table public.odemeler drop constraint if exists odemeler_tutar_check;
alter table public.odemeler add constraint odemeler_tutar_check check (tutar <> 0);

-- İsteğe bağlı etiket (raporlarda kullanılır)
alter table public.odemeler add column if not exists tip text
  not null default 'tahsilat'
  check (tip in ('tahsilat','iade'));

-- Eski kayıtlarda tip tutarsızsa düzelt
update public.odemeler set tip = case when tutar < 0 then 'iade' else 'tahsilat' end
  where tip is distinct from (case when tutar < 0 then 'iade' else 'tahsilat' end);

-- 2) İade/tahsilat hazırlığı: iptal edilmiş siparişe iade yapılabilir (net odenen > 0 iken)
create or replace function public.odeme_hazirla() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare siparis public.girisler%rowtype;
begin
  select * into siparis from public.girisler where id = new.giris_id;
  if not found then raise exception 'Sipariş bulunamadı'; end if;

  -- tip / işaret tutarlılığı
  if new.tutar < 0 then
    new.tip := 'iade';
  else
    new.tip := coalesce(nullif(new.tip,''), 'tahsilat');
    if new.tip = 'iade' then
      new.tutar := -abs(new.tutar);
    end if;
  end if;

  if new.tip = 'tahsilat' then
    if siparis.iptal then raise exception 'İptal edilmiş siparişe tahsilat alınamaz'; end if;
  else
    -- iade: net ödenen kadar olabilir (aşağıda odeme_topla da kontrol eder)
    if siparis.odenen <= 0.005 and new.tutar < 0 then
      raise exception 'İade edilecek ödeme yok';
    end if;
  end if;

  new.sube_id := siparis.sube_id;
  new.alan := auth.uid();
  new.alan_ad := (select p.ad from public.profiller p where p.id = auth.uid());
  new.zaman := now();
  return new;
end $$;

-- 3) Net ödeme toplamı: negatif iadeler dahil; net 0 altına düşmesin; toplamı aşmasın
create or replace function public.odeme_topla() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare gid uuid; ode numeric; tg numeric;
begin
  gid := coalesce(new.giris_id, old.giris_id);
  select coalesce(sum(tutar), 0) into ode from public.odemeler where giris_id = gid;
  if ode < -0.005 then
    raise exception 'İade tutarı alınan ödemeyi aşıyor';
  end if;
  select toplam into tg from public.girisler where id = gid;
  if tg is not null and ode > tg + 0.005 then
    raise exception 'Ödeme toplamı giriş tutarını aşıyor';
  end if;
  update public.girisler set odenen = ode where id = gid;
  return null;
end $$;

-- 4) İptal kuralı: net tahsilat (odenen) > 0 ise engelle; iade sonrası 0 olunca iptal serbest
create or replace function public.siparis_guvenlik_kontrol() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.iptal is distinct from old.iptal and new.iptal then
    if coalesce(old.odenen, 0) > 0.005 then
      raise exception 'Tahsilatı olan sipariş iptal edilemez. Önce iade yapın (net ödenen 0 olmalı).';
    end if;
  end if;
  return new;
end $$;

-- 5) Merkez ödeme silebilsin (yanlış giriş düzeltmesi)
grant delete on public.odemeler to authenticated;

drop policy if exists odeme_sil on public.odemeler;
create policy odeme_sil on public.odemeler for delete to authenticated
  using (public.benim_rolum() = 'merkez');

-- Silme sonrası odenen güncellemesi zaten odeme_sonra (DELETE) trigger'ında

-- 6) Fiş no arama indeksi
create index if not exists girisler_no_idx on public.girisler (no);

-- 7) Günlük kasa için zaman indeksi (varsa dokunma)
create index if not exists odemeler_zaman_idx on public.odemeler (zaman);
create index if not exists odemeler_sube_zaman_idx on public.odemeler (sube_id, zaman desc);
