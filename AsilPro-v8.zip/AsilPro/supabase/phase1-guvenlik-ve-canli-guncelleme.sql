-- AsilPro 1. Aşama: mevcut projeye güvenli iyileştirmeler
-- ÖNCE Supabase veritabanı yedeği alın. SQL Editor'de tek seferde çalıştırın.
-- Bu dosya tablo/veri silmez; mevcut verileri değiştirmez.

-- 1) İptal edilmiş siparişe yeni tahsilat yazılmasını engelle ve tahsilat kaydının
--    sipariş/şube bağlantısını sunucu tarafında belirle.
create or replace function public.odeme_hazirla() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare siparis public.girisler%rowtype;
begin
  select * into siparis from public.girisler where id = new.giris_id;
  if not found then raise exception 'Sipariş bulunamadı'; end if;
  if siparis.iptal then raise exception 'İptal edilmiş siparişe tahsilat alınamaz'; end if;
  new.sube_id := siparis.sube_id;
  new.alan := auth.uid();
  new.alan_ad := (select p.ad from public.profiller p where p.id = auth.uid());
  new.zaman := now();
  return new;
end $$;

-- 2) Tahsilatı olan siparişin doğrudan iptal edilmesini engelle.
-- Önce ayrı bir iade/ters kayıt akışı gerekir; mevcut arayüzde iade modülü yok.
create or replace function public.siparis_guvenlik_kontrol() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.iptal is distinct from old.iptal and new.iptal then
    if exists (select 1 from public.odemeler o where o.giris_id = old.id) then
      raise exception 'Tahsilatı olan sipariş iptal edilemez. Önce iade işlemi için merkezle görüşün.';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists siparis_guvenlik_kontrol_t on public.girisler;
create trigger siparis_guvenlik_kontrol_t
  before update of iptal on public.girisler
  for each row execute function public.siparis_guvenlik_kontrol();

-- 3) Ödeme kayıtlarının doğrudan düzenlenmesini kapat. Yeni tahsilatlar INSERT ile,
--    mevcut silme politikası/RLS kurallarıyla yönetilir; arayüzde ödeme düzenleme yok.
revoke update on public.odemeler from authenticated;

-- 4) Canlı güncelleme: sipariş, ödeme ve müşteri değişiklikleri aboneliğe açılır.
--    Zaten yayında olan tablolar için tekrar ekleme hataları güvenle yutulur.
do $$ begin
  alter publication supabase_realtime add table public.girisler;
exception when duplicate_object then null; when duplicate_table then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.odemeler;
exception when duplicate_object then null; when duplicate_table then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.musteriler;
exception when duplicate_object then null; when duplicate_table then null; end $$;

-- 5) Performans indeksleri: sayfalama ve tarih aralığı raporları.
create index if not exists girisler_olusturma_idx on public.girisler (olusturma desc);
create index if not exists odemeler_zaman_idx on public.odemeler (zaman);
create index if not exists musteriler_ad_idx on public.musteriler (ad);
