// Supabase Edge Function: whatsapp-gonder
// WhatsApp Cloud API ile metin mesajı gönderir.
// Kurulum: Edge Functions > Create > adı tam: whatsapp-gonder > Deploy
// Secrets (opsiyonel, ayarlar tablosuna alternatif): WHATSAPP_TOKEN, WHATSAPP_PHONE_ID
// İstemci Authorization: kullanıcı JWT'si gönderir.
import { createClient } from "npm:@supabase/supabase-js@2";

const anahtar = (yeni: string, eski: string): string => {
  try {
    const v = Deno.env.get(yeni);
    if (v) {
      const k = JSON.parse(v)["default"];
      if (k) return k as string;
    }
  } catch (_e) { /* eski */ }
  return Deno.env.get(eski)!;
};

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), {
    status: s,
    headers: { ...cors, "Content-Type": "application/json" },
  });

function telNormalize(t: string): string | null {
  let d = String(t || "").replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.startsWith("0")) d = d.slice(1);
  if (d.length === 10) d = "90" + d;
  return d.length >= 11 && d.length <= 15 ? d : null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = anahtar("SUPABASE_PUBLISHABLE_KEYS", "SUPABASE_ANON_KEY");
    const service = anahtar("SUPABASE_SECRET_KEYS", "SUPABASE_SERVICE_ROLE_KEY");

    const caller = createClient(url, anon, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: { user } } = await caller.auth.getUser();
    if (!user) return json({ hata: "Önce giriş yapın." }, 401);

    const admin = createClient(url, service, { auth: { persistSession: false } });
    const { data: me } = await admin.from("profiller").select("rol").eq("id", user.id).maybeSingle();
    if (!me) return json({ hata: "Yetkisiz." }, 403);

    const body = await req.json();
    const to = telNormalize(String(body.tel || ""));
    const text = String(body.metin || "").trim();
    if (!to) return json({ hata: "Geçerli telefon yok." }, 400);
    if (!text) return json({ hata: "Mesaj boş." }, 400);

    // Kimlik bilgileri: önce ortam değişkeni, yoksa ayarlar tablosu
    let token = Deno.env.get("WHATSAPP_TOKEN") || "";
    let phoneId = Deno.env.get("WHATSAPP_PHONE_ID") || "";
    if (!token || !phoneId) {
      const { data: ay } = await admin.from("ayarlar").select("deger").eq("anahtar", "whatsapp").maybeSingle();
      const d = (ay && ay.deger) || {};
      if (!token) token = String(d.token || "");
      if (!phoneId) phoneId = String(d.phone_id || "");
      if (d.enabled === false) return json({ hata: "WhatsApp gönderimi kapalı." }, 400);
    }
    if (!token || !phoneId) {
      return json({ hata: "WhatsApp API ayarları eksik (token / phone_id)." }, 400);
    }

    const api = `https://graph.facebook.com/v21.0/${phoneId}/messages`;
    const res = await fetch(api, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { preview_url: false, body: text.slice(0, 4096) },
      }),
    });
    const raw = await res.text();
    let parsed: Record<string, unknown> = {};
    try { parsed = JSON.parse(raw); } catch (_e) { parsed = { raw }; }
    if (!res.ok) {
      const errMsg = (parsed.error as { message?: string })?.message || raw.slice(0, 200);
      return json({ hata: "WhatsApp API: " + errMsg }, 502);
    }
    return json({ tamam: true, id: (parsed.messages as { id: string }[])?.[0]?.id || null });
  } catch (e) {
    return json({ hata: String(e?.message || e) }, 500);
  }
});
