-- AsilPro v8 (sade) - sadece WhatsApp otomatik gönderim ayarı
-- Stok / KDV / barkod / çoklu dil YOK.
-- Mevcut proje: yedek al, SQL Editor'de çalıştır.

insert into public.ayarlar (anahtar, deger)
values (
  'whatsapp',
  jsonb_build_object(
    'auto', false,
    'phone_id', '',
    'token', '',
    'enabled', false
  )
)
on conflict (anahtar) do nothing;
