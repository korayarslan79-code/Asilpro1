-- AsilPro v0.4 - Supabase kurulumu
-- Supabase > SQL Editor > New query > tamamını yapıştırıp Run.

-- 1) TABLOLAR ---------------------------------------------------------
create table if not exists public.subeler (
  id uuid primary key default gen_random_uuid(),
  ad text not null unique,
  tur text not null default 'sube' check (tur in ('sube','terzi')),
  aktif boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.profiller (
  id uuid primary key references auth.users(id) on delete cascade,
  rol text not null check (rol in ('merkez','sube')),
  sube_id uuid references public.subeler(id),
  ad text,
  check (rol = 'merkez' or sube_id is not null)
);

create table if not exists public.fiyatlar (
  id uuid primary key default gen_random_uuid(),
  ad text not null,
  fiyat numeric(10,2) not null default 0,
  sira int not null default 0,
  aktif boolean not null default true
);

create table if not exists public.musteriler (
  id uuid primary key default gen_random_uuid(),
  sube_id uuid not null references public.subeler(id),
  ad text not null,
  tel text,
  tel_key text,
  notu text,
  created_at timestamptz not null default now(),
  unique (sube_id, tel_key)
);

create table if not exists public.girisler (
  id uuid primary key default gen_random_uuid(),
  no bigint generated always as identity (start with 1001),
  sube_id uuid not null references public.subeler(id),
  musteri_id uuid references public.musteriler(id),
  ad text not null,
  tel text,
  notu text,
  kalemler jsonb not null default '[]'::jsonb,
  toplam numeric(10,2) not null default 0,
  odenen numeric(10,2) not null default 0,          -- ödemeler tablosundan otomatik hesaplanır
  durum smallint not null default 0 check (durum between 0 and 5),   -- 0 Teslim alındı, 1 Merkeze ulaştı, 2 İşlemde, 3 Hazır, 4 Şubeye ulaştı, 5 Teslim edildi
  teslim_tarihi date,                                -- tahmini teslim günü
  hazir_zaman timestamptz,                           -- müşterinin alması için hazır olduğu an (şubeye ulaştı; terzide hazır) - alınmayan uyarısı için
  iptal boolean not null default false,
  iptal_nedeni text,
  iptal_zaman timestamptz,
  olusturma timestamptz not null default now()
);
create index if not exists girisler_sube_idx on public.girisler (sube_id, olusturma desc);

-- Her tahsilat ayrı kayıt: kim, ne zaman, ne kadar, hangi yöntemle
create table if not exists public.odemeler (
  id uuid primary key default gen_random_uuid(),
  giris_id uuid not null references public.girisler(id) on delete cascade,
  sube_id uuid not null references public.subeler(id),
  tutar numeric(10,2) not null check (tutar <> 0),  -- negatif = iade
  tip text not null default 'tahsilat' check (tip in ('tahsilat','iade')),
  yontem text not null default 'Nakit' check (yontem in ('Nakit','Kart','Havale')),
  alan uuid,           -- tahsilatı alan kullanıcı (otomatik)
  alan_ad text,        -- adı (otomatik)
  zaman timestamptz not null default now()
);
create index if not exists odemeler_giris_idx on public.odemeler (giris_id);

-- Merkezin düzenlediği ayarlar (ör. aşama mesajları)
create table if not exists public.ayarlar (
  anahtar text primary key,
  deger jsonb not null,
  guncelleme timestamptz not null default now()
);

-- 2) YARDIMCI FONKSİYONLAR --------------------------------------------
-- Durdurulmuş (aktif=false) şube/terzi hesapları hiçbir veriyi göremez.
create or replace function public.benim_rolum() returns text
language sql stable security definer set search_path = public as
$$ select p.rol from public.profiller p
   left join public.subeler s on s.id = p.sube_id
   where p.id = auth.uid() and (p.rol = 'merkez' or s.aktif) $$;

create or replace function public.benim_subem() returns uuid
language sql stable security definer set search_path = public as
$$ select p.sube_id from public.profiller p
   join public.subeler s on s.id = p.sube_id
   where p.id = auth.uid() and s.aktif $$;

-- 3) ÖDEME KURALLARI (otomatik) ----------------------------------------
-- Tahsilatı kimin aldığı istemciden değil, giriş yapan kullanıcıdan alınır.
create or replace function public.odeme_hazirla() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.sube_id := (select sube_id from public.girisler where id = new.giris_id);  -- başka şubenin girişine ödeme yazılamaz
  new.alan := auth.uid();
  new.alan_ad := (select ad from public.profiller where id = auth.uid());
  new.zaman := now();
  return new;
end $$;
drop trigger if exists odeme_once on public.odemeler;
create trigger odeme_once before insert on public.odemeler
  for each row execute function public.odeme_hazirla();

-- Girişin "odenen" tutarı ödemelerin toplamıdır; toplamı aşan ödeme reddedilir.
create or replace function public.odeme_topla() returns trigger
language plpgsql security definer set search_path = public as $$
declare gid uuid; ode numeric; tg numeric;
begin
  gid := coalesce(new.giris_id, old.giris_id);
  select coalesce(sum(tutar), 0) into ode from public.odemeler where giris_id = gid;
  select toplam into tg from public.girisler where id = gid;
  if tg is not null and ode > tg + 0.005 then
    raise exception 'Ödeme toplamı giriş tutarını aşıyor';
  end if;
  update public.girisler set odenen = ode where id = gid;
  return null;
end $$;
drop trigger if exists odeme_sonra on public.odemeler;
create trigger odeme_sonra after insert or delete on public.odemeler
  for each row execute function public.odeme_topla();

-- Giriş tutarı, alınan ödemenin altına düşürülemez.
create or replace function public.giris_kontrol() returns trigger
language plpgsql as $$
begin
  if new.toplam < new.odenen - 0.005 then
    raise exception 'Toplam, alınan ödemeden düşük olamaz';
  end if;
  return new;
end $$;
drop trigger if exists giris_kontrol_t on public.girisler;
create trigger giris_kontrol_t before update on public.girisler
  for each row execute function public.giris_kontrol();

-- Aşama kilidi: şube çalışanı yalnızca "Şubeye ulaştı" (4) ve "Teslim edildi" (5) aşamalarına
-- ileri doğru geçirebilir. Merkez her aşamayı değiştirebilir. Terzi birimi kendi işini yönetir.
create or replace function public.durum_kontrol() returns trigger
language plpgsql security definer set search_path = public as $$
declare r text; t text;
begin
  if new.durum is distinct from old.durum and auth.uid() is not null then
    select p.rol, s.tur into r, t
      from public.profiller p left join public.subeler s on s.id = p.sube_id
      where p.id = auth.uid();
    if r is null then raise exception 'Yetkisiz'; end if;
    if r <> 'merkez' and coalesce(t, 'sube') <> 'terzi' then
      if not (new.durum in (4, 5) and new.durum > old.durum) then
        raise exception 'Bu aşamayı şube değiştiremez';
      end if;
    end if;
  end if;
  return new;
end $$;
drop trigger if exists durum_kontrol_t on public.girisler;
create trigger durum_kontrol_t before update on public.girisler
  for each row execute function public.durum_kontrol();

-- Şube/terzi, "odenen" alanını doğrudan değiştiremez (sadece ödeme kaydıyla değişir).
revoke insert, update on public.girisler from authenticated;
grant insert (sube_id, musteri_id, ad, tel, notu, kalemler, toplam, teslim_tarihi)
  on public.girisler to authenticated;
grant update (ad, tel, notu, kalemler, toplam, durum, teslim_tarihi, hazir_zaman, iptal, iptal_nedeni, iptal_zaman)
  on public.girisler to authenticated;

-- 4) GÜVENLİK (RLS): şube/terzi sadece kendi verisini görür, merkez hepsini ---
alter table public.subeler    enable row level security;
alter table public.profiller  enable row level security;
alter table public.fiyatlar   enable row level security;
alter table public.musteriler enable row level security;
alter table public.girisler   enable row level security;
alter table public.odemeler   enable row level security;
alter table public.ayarlar    enable row level security;

drop policy if exists profil_oku on public.profiller;
create policy profil_oku on public.profiller for select to authenticated
  using (id = auth.uid() or public.benim_rolum() = 'merkez');

drop policy if exists sube_oku on public.subeler;
create policy sube_oku on public.subeler for select to authenticated
  using (public.benim_rolum() = 'merkez' or id = public.benim_subem());

drop policy if exists fiyat_oku on public.fiyatlar;
create policy fiyat_oku on public.fiyatlar for select to authenticated
  using (public.benim_rolum() is not null);
drop policy if exists fiyat_yaz on public.fiyatlar;
create policy fiyat_yaz on public.fiyatlar for all to authenticated
  using (public.benim_rolum() = 'merkez') with check (public.benim_rolum() = 'merkez');

drop policy if exists musteri_oku on public.musteriler;
create policy musteri_oku on public.musteriler for select to authenticated
  using (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists musteri_ekle on public.musteriler;
create policy musteri_ekle on public.musteriler for insert to authenticated
  with check (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists musteri_guncelle on public.musteriler;
create policy musteri_guncelle on public.musteriler for update to authenticated
  using (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem())
  with check (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists musteri_sil on public.musteriler;
create policy musteri_sil on public.musteriler for delete to authenticated
  using (public.benim_rolum() = 'merkez');

drop policy if exists giris_oku on public.girisler;
create policy giris_oku on public.girisler for select to authenticated
  using (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists giris_ekle on public.girisler;
create policy giris_ekle on public.girisler for insert to authenticated
  with check (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists giris_guncelle on public.girisler;
create policy giris_guncelle on public.girisler for update to authenticated
  using (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem())
  with check (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists giris_sil on public.girisler;
create policy giris_sil on public.girisler for delete to authenticated
  using (public.benim_rolum() = 'merkez');

drop policy if exists odeme_oku on public.odemeler;
create policy odeme_oku on public.odemeler for select to authenticated
  using (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists odeme_ekle on public.odemeler;
create policy odeme_ekle on public.odemeler for insert to authenticated
  with check (public.benim_rolum() = 'merkez' or sube_id = public.benim_subem());
drop policy if exists odeme_sil on public.odemeler;
create policy odeme_sil on public.odemeler for delete to authenticated
  using (public.benim_rolum() = 'merkez');

drop policy if exists ayar_oku on public.ayarlar;
create policy ayar_oku on public.ayarlar for select to authenticated
  using (public.benim_rolum() is not null);
drop policy if exists ayar_yaz on public.ayarlar;
create policy ayar_yaz on public.ayarlar for all to authenticated
  using (public.benim_rolum() = 'merkez') with check (public.benim_rolum() = 'merkez');

-- 5) CANLI GÜNCELLEME (şubede girilen kayıt merkezde anında görünsün) --
do $$ begin
  alter publication supabase_realtime add table public.girisler;
exception when duplicate_object then null; end $$;

-- 6) ÖRNEK FİYAT LİSTESİ (uygulamadan değiştirebilirsiniz) ------------
insert into public.fiyatlar (ad, fiyat, sira)
select * from (values
  ('Pantolon',150,1),('Gömlek',100,2),('Ceket',200,3),('Elbise',250,4),
  ('Takım elbise',400,5),('Mont',350,6),('Palto',350,7),('Kazak',120,8),
  ('Halı (m²)',120,9),('Perde (kg)',140,10)
) as v(ad,fiyat,sira)
where not exists (select 1 from public.fiyatlar);

-- 7) ŞUBELER VE KULLANICILAR -------------------------------------------
-- Önce kendi şube adlarınızı yazın:
insert into public.subeler (ad) values ('Şube 1'), ('Şube 2') on conflict (ad) do nothing;

-- MERKEZ hesabınız için ayrı dosyayı kullanın: merkez-hesabi.sql
-- (Önce Authentication > Users bölümünden kullanıcıyı açmanız gerekir.)

-- Şube ve terzi hesaplarını sonradan uygulamadaki Merkez > Hesaplar bölümünden
-- açın (hesap-ac.ts fonksiyonunu kurduktan sonra). İsterseniz ilk şubeleri elle de açabilirsiniz:
-- insert into public.profiller (id, rol, sube_id, ad)
--   select u.id, 'sube', s.id, s.ad
--   from auth.users u, public.subeler s
--   where u.email = 'sube1@ornek.com' and s.ad = 'Şube 1';

-- ÖNEMLİ: Authentication > Sign In / Providers bölümünde
-- "Allow new users to sign up" seçeneğini KAPATIN.
-- AsilPro 1. Aşama: mevcut projeye güvenli iyileştirmeler
-- ÖNCE Supabase veritabanı yedeği alın. SQL Editor'de tek seferde çalıştırın.
-- Bu dosya tablo/veri silmez; mevcut verileri değiştirmez.

-- 1) İptal edilmiş siparişe yeni tahsilat yazılmasını engelle ve tahsilat kaydının
--    sipariş/şube bağlantısını sunucu tarafında belirle.
create or replace function public.odeme_hazirla() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare siparis public.girisler%rowtype;
begin
  select * into siparis from public.girisler where id = new.giris_id;
  if not found then raise exception 'Sipariş bulunamadı'; end if;
  if siparis.iptal then raise exception 'İptal edilmiş siparişe tahsilat alınamaz'; end if;
  new.sube_id := siparis.sube_id;
  new.alan := auth.uid();
  new.alan_ad := (select p.ad from public.profiller p where p.id = auth.uid());
  new.zaman := now();
  return new;
end $$;

-- 2) Tahsilatı olan siparişin doğrudan iptal edilmesini engelle.
-- Önce ayrı bir iade/ters kayıt akışı gerekir; mevcut arayüzde iade modülü yok.
create or replace function public.siparis_guvenlik_kontrol() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.iptal is distinct from old.iptal and new.iptal then
    if exists (select 1 from public.odemeler o where o.giris_id = old.id) then
      raise exception 'Tahsilatı olan sipariş iptal edilemez. Önce iade işlemi için merkezle görüşün.';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists siparis_guvenlik_kontrol_t on public.girisler;
create trigger siparis_guvenlik_kontrol_t
  before update of iptal on public.girisler
  for each row execute function public.siparis_guvenlik_kontrol();

-- 3) Ödeme kayıtlarının doğrudan düzenlenmesini kapat. Yeni tahsilatlar INSERT ile,
--    mevcut silme politikası/RLS kurallarıyla yönetilir; arayüzde ödeme düzenleme yok.
revoke update on public.odemeler from authenticated;

-- 4) Canlı güncelleme: sipariş, ödeme ve müşteri değişiklikleri aboneliğe açılır.
--    Zaten yayında olan tablolar için tekrar ekleme hataları güvenle yutulur.
do $$ begin
  alter publication supabase_realtime add table public.girisler;
exception when duplicate_object then null; when duplicate_table then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.odemeler;
exception when duplicate_object then null; when duplicate_table then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.musteriler;
exception when duplicate_object then null; when duplicate_table then null; end $$;

-- 5) Performans indeksleri: sayfalama ve tarih aralığı raporları.
create index if not exists girisler_olusturma_idx on public.girisler (olusturma desc);
create index if not exists odemeler_zaman_idx on public.odemeler (zaman);
create index if not exists musteriler_ad_idx on public.musteriler (ad);

-- v7: iade için tutar <> 0 ve tip sütunu yukarıda tanımlı. Mevcut projeler phase2-iade-kasa-csv.sql çalıştırsın.
