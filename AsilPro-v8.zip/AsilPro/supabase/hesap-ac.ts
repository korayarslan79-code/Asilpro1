// Supabase Edge Function: hesap-ac
// Merkez, uygulamadan şube/terzi hesabı açar, şifre değiştirir, hesabı durdurur.
// Kurulum: Supabase > Edge Functions > Create a new function > adı: hesap-ac
// Bu dosyanın içeriğini yapıştırıp Deploy edin. Ek anahtar girmeniz gerekmez: SUPABASE_URL ile
// publishable/secret anahtarlar Supabase tarafından fonksiyona otomatik verilir.
// (Yeni anahtarlar yoksa eski anon / service_role anahtarlarına geri döner.)
import { createClient } from "npm:@supabase/supabase-js@2";

// Yeni anahtar sistemi (SUPABASE_PUBLISHABLE_KEYS / SUPABASE_SECRET_KEYS), yoksa eski anahtarlar
const anahtar = (yeni: string, eski: string): string => {
  try {
    const v = Deno.env.get(yeni);
    if (v) { const k = JSON.parse(v)["default"]; if (k) return k as string; }
  } catch (_e) { /* eski anahtara dön */ }
  return Deno.env.get(eski)!;
};

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = anahtar("SUPABASE_PUBLISHABLE_KEYS", "SUPABASE_ANON_KEY");
    const service = anahtar("SUPABASE_SECRET_KEYS", "SUPABASE_SERVICE_ROLE_KEY");

    // 1) Çağıran kişi giriş yapmış ve MERKEZ mi?
    const caller = createClient(url, anon, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
    const { data: { user } } = await caller.auth.getUser();
    if (!user) return json({ hata: "Önce giriş yapın." }, 401);
    const admin = createClient(url, service, { auth: { persistSession: false } });
    const { data: me } = await admin.from("profiller").select("rol").eq("id", user.id).maybeSingle();
    if (me?.rol !== "merkez") return json({ hata: "Bu işlem için yetkiniz yok." }, 403);

    const b = await req.json();

    // 2) Yeni hesap aç
    if (b.islem === "ac") {
      const ad = String(b.ad ?? "").trim();
      const email = String(b.email ?? "").trim().toLowerCase();
      const sifre = String(b.sifre ?? "");
      const tur = b.tur === "terzi" ? "terzi" : "sube";
      if (!ad || !email || sifre.length < 8) return json({ hata: "Ad, e-posta ve en az 8 karakterlik şifre gerekli." }, 400);

      const { data: s, error: e1 } = await admin.from("subeler").insert({ ad, tur }).select().single();
      if (e1) return json({ hata: "Bu ad zaten kayıtlı olabilir." }, 400);

      const { data: u, error: e2 } = await admin.auth.admin.createUser({ email, password: sifre, email_confirm: true });
      if (e2 || !u?.user) {
        await admin.from("subeler").delete().eq("id", s.id);
        return json({ hata: e2?.message ?? "Kullanıcı açılamadı." }, 400);
      }
      const { error: e3 } = await admin.from("profiller").insert({ id: u.user.id, rol: "sube", sube_id: s.id, ad });
      if (e3) {
        await admin.auth.admin.deleteUser(u.user.id);
        await admin.from("subeler").delete().eq("id", s.id);
        return json({ hata: "Profil oluşturulamadı." }, 500);
      }
      return json({ tamam: true, id: s.id });
    }

    // 3) Mevcut hesap üzerinde işlem
    const { data: prof } = await admin.from("profiller").select("id").eq("sube_id", b.sube_id).eq("rol", "sube").maybeSingle();
    if (!prof) return json({ hata: "Hesap bulunamadı." }, 404);

    if (b.islem === "sifre") {
      if (String(b.sifre ?? "").length < 8) return json({ hata: "Şifre en az 8 karakter olmalı." }, 400);
      const { error } = await admin.auth.admin.updateUserById(prof.id, { password: b.sifre });
      return error ? json({ hata: error.message }, 400) : json({ tamam: true });
    }
    if (b.islem === "pasif" || b.islem === "aktif") {
      const on = b.islem === "aktif";
      await admin.from("subeler").update({ aktif: on }).eq("id", b.sube_id);
      await admin.auth.admin.updateUserById(prof.id, { ban_duration: on ? "none" : "876000h" });
      return json({ tamam: true });
    }
    return json({ hata: "Geçersiz işlem." }, 400);
  } catch (_e) {
    return json({ hata: "Beklenmeyen bir hata oluştu." }, 500);
  }
});
