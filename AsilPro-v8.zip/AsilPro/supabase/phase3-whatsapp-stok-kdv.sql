-- AsilPro v8 - WhatsApp otomatik, stok, KDV, barkod
-- Mevcut proje: yedek al, SQL Editor'de çalıştır.
-- Yeni kurulumda schema.sql + phase1 + phase2'den sonra.

-- 1) Fiyat listesine stok ve barkod
alter table public.fiyatlar add column if not exists stok numeric(12,2);
alter table public.fiyatlar add column if not exists barkod text;
alter table public.fiyatlar add column if not exists kdv_oran numeric(5,2) not null default 20;
create unique index if not exists fiyatlar_barkod_uidx on public.fiyatlar (barkod) where barkod is not null and barkod <> '';

-- 2) Siparişte KDV özeti (isteğe bağlı alan; kalemler jsonb içinde de tutulabilir)
alter table public.girisler add column if not exists kdv_toplam numeric(10,2) not null default 0;

-- 3) Stok düşümü: yeni siparişte aktif ürün stokları azalır (stok null = sınırsız)
create or replace function public.stok_dus() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare item jsonb; fid uuid; adet numeric; mevcut numeric;
begin
  if tg_op = 'INSERT' and new.iptal is not true then
    for item in select * from jsonb_array_elements(coalesce(new.kalemler, '[]'::jsonb))
    loop
      fid := nullif(item->>'id','')::uuid;
      adet := coalesce((item->>'adet')::numeric, 0);
      if fid is null or adet <= 0 then continue; end if;
      select stok into mevcut from public.fiyatlar where id = fid for update;
      if mevcut is not null then
        if mevcut < adet then
          raise exception 'Yetersiz stok: % (kalan %)', coalesce(item->>'ad','ürün'), mevcut;
        end if;
        update public.fiyatlar set stok = stok - adet where id = fid;
      end if;
    end loop;
  end if;
  return new;
end $$;
drop trigger if exists stok_dus_t on public.girisler;
create trigger stok_dus_t after insert on public.girisler
  for each row execute function public.stok_dus();

-- İptal edilince stoku geri ekle (yalnızca iptal bayrağı true olduğunda bir kez)
create or replace function public.stok_iade_iptal() returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare item jsonb; fid uuid; adet numeric;
begin
  if new.iptal is true and old.iptal is not true then
    for item in select * from jsonb_array_elements(coalesce(new.kalemler, '[]'::jsonb))
    loop
      fid := nullif(item->>'id','')::uuid;
      adet := coalesce((item->>'adet')::numeric, 0);
      if fid is null or adet <= 0 then continue; end if;
      update public.fiyatlar set stok = stok + adet where id = fid and stok is not null;
    end loop;
  end if;
  -- iptal geri alınırsa tekrar düş
  if new.iptal is not true and old.iptal is true then
    for item in select * from jsonb_array_elements(coalesce(new.kalemler, '[]'::jsonb))
    loop
      fid := nullif(item->>'id','')::uuid;
      adet := coalesce((item->>'adet')::numeric, 0);
      if fid is null or adet <= 0 then continue; end if;
      update public.fiyatlar
        set stok = case when stok is null then null else stok - adet end
        where id = fid and stok is not null;
    end loop;
  end if;
  return new;
end $$;
drop trigger if exists stok_iade_iptal_t on public.girisler;
create trigger stok_iade_iptal_t after update of iptal on public.girisler
  for each row execute function public.stok_iade_iptal();

-- 4) WhatsApp ayar anahtarı (token istemciye gitmez; Edge Function service role ile okur)
insert into public.ayarlar (anahtar, deger)
values (
  'whatsapp',
  jsonb_build_object(
    'auto', false,
    'phone_id', '',
    'token', '',
    'enabled', false
  )
)
on conflict (anahtar) do nothing;

-- 5) Genel ayarlar: varsayılan KDV, dil, tema tercihi sunucu tarafı (tema cihazda da tutulur)
insert into public.ayarlar (anahtar, deger)
values ('genel', jsonb_build_object('kdv_oran', 20, 'dil', 'tr', 'stok_uyari', 5))
on conflict (anahtar) do nothing;
