// AsilPro servis çalışanı: uygulama dosyalarını saklar, internet yokken ekranın açılmasını sağlar.
// Veriler (Supabase) hiçbir zaman saklanmaz. Uygulamada değişiklik yaptığınızda V sürümünü artırın.
const V = "asilpro-v8";
const SHELL = ["./", "index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png"];
const CDN = ["cdn.jsdelivr.net", "fonts.googleapis.com", "fonts.gstatic.com"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(V).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== V).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const r = e.request;
  if (r.method !== "GET") return;
  const u = new URL(r.url);
  if (u.hostname.endsWith("supabase.co") || u.hostname.endsWith("supabase.in")) return; // veri hep canlı
  if (u.origin !== self.location.origin && !CDN.includes(u.hostname)) return;
  e.respondWith(
    fetch(r)
      .then((res) => {
        if (res.ok || res.type === "opaque") {
          const kopya = res.clone();
          caches.open(V).then((c) => c.put(r, kopya));
        }
        return res;
      })
      .catch(() => caches.match(r).then((m) => m || (r.mode === "navigate" ? caches.match("index.html") : undefined)))
  );
});
